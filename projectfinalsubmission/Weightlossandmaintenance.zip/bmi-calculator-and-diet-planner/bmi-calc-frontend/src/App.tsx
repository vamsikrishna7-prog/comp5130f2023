import { BrowserRouter, Navigate, Route, Routes } from "react-router-dom";
import "./App.css";
import Dashboard from "./Components/Dashboard";
import Landing from "./Components/Landing";
import Login from "./Components/Login";
import Register from "./Components/Register";
import AuthLanding from "./Components/AuthLanding";
import { DietPlan } from "./Components/Dietplans";

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Navigate to="/bmi" />} />
        <Route path="/auth" element={<AuthLanding />}>
          <Route path="login" element={<Login />} />
          <Route path="register" element={<Register />} />
        </Route>
        <Route path="/bmi" element={<Landing />}>
          <Route index element={<Dashboard />} />
          <Route path="diet-and-workout" element={<DietPlan />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}

export default App;
