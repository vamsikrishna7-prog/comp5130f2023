import { Button, Stack } from "@mui/material";
import { Login as BnpLogin } from "bnp-react-auth";
import React from "react";
import { useNavigate } from "react-router-dom";
import { AuthService } from "../services/auth.service";
import { StorageService } from "../services/storage.service";
import { ValidatorService } from "../services/validator.service";

export default function Login() {
  const navigate = useNavigate();
  const [userDetails, setUserDetails] = React.useState({
    email: "",
    password: "",
  });

  function onChange({ field, value }: any) {
    setUserDetails((currValue: any) => ({ ...currValue, [field]: value }));
  }

  function checkDetailsBeforeLogin() {
    if (!ValidatorService.isEmailValid(userDetails.email)) {
      alert("Please enter a valid email to login");
      return false;
    }

    if (!ValidatorService.isInputValid(userDetails.password)) {
      alert("Please enter a valid password to login");
      return false;
    }

    return true;
  }

  async function onLogin() {
    if (checkDetailsBeforeLogin())
      try {
        const res = (await AuthService.loginUser(userDetails))?.data;
        if (res.status === 200 || res.status === 201) {
          StorageService.rememberUser(res.user);
          navigate("/bmi");
        } else {
          alert(res.message);
        }
      } catch (e) {
        console.log(e);
        alert("Something went wrong, try login in again !!");
      }
  }

  return (
    <BnpLogin
      onChange={onChange}
      validators={{
        email: ValidatorService.isEmailValid,
        password: ValidatorService.isInputValid,
      }}
      customLoginButton={
        <Stack
          direction={"row"}
          alignItems={"center"}
          justifyContent={"space-between"}
          className="mt-4"
        >
          <Button variant="text" onClick={() => navigate("/auth/register")}>
            Create account
          </Button>
          <Button
            variant="contained"
            color="success"
            onClick={() => {
              onLogin();
            }}
          >
            Login
          </Button>
        </Stack>
      }
    />
  );
}
