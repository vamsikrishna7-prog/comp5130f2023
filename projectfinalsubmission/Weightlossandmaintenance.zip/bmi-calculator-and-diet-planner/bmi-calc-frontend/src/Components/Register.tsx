import {
  Button,
  Stack,
  TextField,
  ToggleButton,
  ToggleButtonGroup,
  Typography,
} from "@mui/material";
import { Register as BnpRegister } from "bnp-react-register";
import { FieldType } from "bnp-react-register/dist/esm/models/input-type.enum";
import React from "react";
import { useNavigate } from "react-router-dom";
import { AuthService } from "../services/auth.service";
import { ValidatorService } from "../services/validator.service";

export default function Register() {
  const navigate = useNavigate();
  const [userDetails, setUserDetails] = React.useState({
    name: "",
    email: "",
    password: "",
    age: 25,
    phoneNumber: "",
    gender: "female",
  });

  const [ageError, setAgeError] = React.useState<string>("");

  function onChange({ field, value }: any) {
    setUserDetails((currValue: any) => ({ ...currValue, [field]: value }));
  }

  const onAgeChange = (event: any) => {
    const { value: age } = event.target;
    onChange({ field: "age", value: age });

    if (!ValidatorService.isAgeValid(age)) {
      setAgeError("Please enter valid age !!");
    } else {
      setAgeError("");
    }
  };

  function checkDetailsBeforeRegister() {
    if (!ValidatorService.isInputValid(userDetails.name)) {
      alert("Please enter a valid name to create an account");
      return false;
    }

    if (!ValidatorService.isEmailValid(userDetails.email)) {
      alert("Please enter a valid email to create an account");
      return false;
    }

    if (!ValidatorService.isInputValid(userDetails.password)) {
      alert("Please enter a valid password to create an account");
      return false;
    }

    if (!ValidatorService.isAgeValid(userDetails.age)) {
      alert("Please enter a valid age create an account");
      return false;
    }

    if (!ValidatorService.isInputValid(userDetails.gender)) {
      alert("Please select your gender to create an account");
      return false;
    }

    return true;
  }

  async function onRegister() {
    if (checkDetailsBeforeRegister())
      try {
        const res = (await AuthService.registerUser(userDetails))?.data;
        console.log(res);
        if (res.status === 200 || res.status === 201) {
          alert("Account created, please proceed to login !");
          navigate("/auth/login");
        } else {
          alert(res.message);
        }
      } catch (e) {
        console.log(e);
        alert("Something went wrong, try register in again !!");
      }
  }

  return (
    <div className="mt-5">
      <BnpRegister
        headerLabel={"Create an account"}
        fieldsToShow={[
          {
            id: "name",
            field: FieldType.NAME,
            onChange: onChange,
            validation: {
              validator: ValidatorService.isInputValid,
            },
          },
          {
            id: "email",
            field: FieldType.EMAIL,
            onChange: onChange,
            validation: {
              validator: ValidatorService.isEmailValid,
            },
          },
          {
            id: "password",
            field: FieldType.PASSWORD,
            onChange: onChange,
            validation: {
              validator: ValidatorService.isInputValid,
            },
          },
          {
            id: "confPassword",
            field: FieldType.PASSWORD,
            label: "Confirm password",
            onChange: onChange,
            validation: {
              validator: (password: string) => {
                return (
                  ValidatorService.isInputValid(userDetails.password) &&
                  userDetails.password === password
                );
              },
              errorText: "Passwords do not match",
            },
          },
          {
            id: "phoneNumber",
            field: FieldType.PHONE_NUMBER,
            label: "Phone number",
            onChange: onChange,
            validation: {
              validator: ValidatorService.isPhoneNumberValid,
              errorText: "Phone number should be 8 or 10 digits long",
            },
          },
          {
            id: "age",
            field: FieldType.CUSTOM,
            element: (
              <TextField
                className="mt-3 mb-2"
                fullWidth
                label="Age"
                variant="outlined"
                defaultValue={userDetails.age}
                onChange={onAgeChange}
                error={!!ageError?.trim()}
                helperText={ageError}
                type="number"
              />
            ),
          },
          {
            id: "gender",
            field: FieldType.CUSTOM,
            element: (
              <Stack className="my-2" direction="column">
                <Typography
                  variant="body1"
                  sx={{ color: "rgba(0,0,0,.6)", fontSize: ".85rem" }}
                >
                  Gender
                </Typography>
                <ToggleButtonGroup
                  fullWidth
                  color="secondary"
                  value={userDetails.gender}
                  exclusive
                  onChange={(event: any) =>
                    onChange({ field: "gender", value: event.target.value })
                  }
                >
                  <ToggleButton value="male">Male</ToggleButton>
                  <ToggleButton value="female">Female</ToggleButton>
                  <ToggleButton value="others">Others</ToggleButton>
                </ToggleButtonGroup>
              </Stack>
            ),
          },
        ]}
        customRegisterButton={
          <Stack
            direction={"row"}
            alignItems={"center"}
            justifyContent={"space-between"}
            className="mt-4"
          >
            <Button variant="text" onClick={() => navigate("/auth/login")}>
              Sign in
            </Button>
            <Button variant="contained" color="success" onClick={onRegister}>
              Register
            </Button>
          </Stack>
        }
      />
    </div>
  );
}
