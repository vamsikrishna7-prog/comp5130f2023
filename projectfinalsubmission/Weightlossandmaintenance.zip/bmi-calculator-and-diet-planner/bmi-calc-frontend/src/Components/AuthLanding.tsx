import {
  AppBar,
  Box,
  Container,
  Stack,
  Toolbar,
  Typography,
} from "@mui/material";
import React from "react";
import { Outlet } from "react-router-dom";

export default function AuthLanding() {
  return (
    <Box sx={{ flexGrow: 1 }}>
      <AppBar position="fixed">
        <Container>
          <Toolbar className="mx-0 px-0">
            <Typography variant="h4" component="span" sx={{ flexGrow: 1 }}>
              BMI & Diet
            </Typography>
          </Toolbar>
        </Container>
      </AppBar>
      <Stack
        className="auth-bg"
        style={{ height: "100vh" }}
        direction={"row"}
        alignItems={"center"}
        justifyContent={"center"}
      >
        <div style={{ height: "fit-content", width: "30%" }}>
          <Outlet />
        </div>
      </Stack>
    </Box>
  );
}
