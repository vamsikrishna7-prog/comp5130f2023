export class ValidatorService {
  public static isEmailValid(email: string): boolean {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  }

  public static isInputValid(ip: string): boolean {
    return ip?.trim()?.length > 0;
  }

  public static isPhoneNumberValid(ip: string): boolean {
    const phNo = ip?.trim();
    return !Number.isNaN(phNo) && (phNo?.length === 8 || phNo?.length === 10);
  }

  public static isAgeValid(age: any): boolean {
    if (age) {
      if (Number.isNaN(age)) {
        return false;
      }
      if (parseInt(age) <= 0 || parseInt(age) >= 120) {
        return false;
      }

      return true;
    }
    return false;
  }
}
