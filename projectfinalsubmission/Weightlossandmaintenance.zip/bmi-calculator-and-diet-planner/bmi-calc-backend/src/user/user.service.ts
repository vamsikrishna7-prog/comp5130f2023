import { HttpException, HttpStatus, Inject, Injectable } from '@nestjs/common';
import { CreateUserDto } from './dto/create-user.dto';
// import { UpdateUserDto } from './dto/update-user.dto';
import { USER_REPOSITORY } from 'src/constants';
import { User } from './entities/user.entity';

@Injectable()
export class UserService {
  constructor(
    @Inject(USER_REPOSITORY)
    private userRepository: typeof User,
  ) {}
  async create(createUserDto: CreateUserDto): Promise<User | string> {
    const { name, email, password, phoneNumber, age, gender } = createUserDto;

    if (!email || !name || !password) {
      throw new HttpException(
        'Email, name, password is required',
        HttpStatus.BAD_REQUEST,
      );
    }
    const existingUser = await this.userRepository.findOne({
      where: { email },
    });
    if (existingUser) {
      throw new HttpException(
        'User with this email already exists',
        HttpStatus.BAD_REQUEST,
      );
    }
    const newUser = new User({
      name,
      email,
      password,
      phoneNumber,
      age,
      gender,
    });
    const savedUser = await newUser.save();
    savedUser.password = '***';
    return savedUser;
  }

  async login(
    email: string,
    password: string,
  ): Promise<{ status: number; user?: User; message: string }> {
    const user = await this.userRepository.findOne({
      where: { email, password },
    });

    if (user) {
      user.password = '***';
      return { status: 200, user, message: 'Login successful' };
    } else {
      return { status: 404, message: 'User not found or invalid credentials' };
    }
  }
}
