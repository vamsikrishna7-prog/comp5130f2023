import LogoutIcon from "@mui/icons-material/Logout";
import {
  AppBar,
  Avatar,
  Box,
  Button,
  Container,
  Divider,
  IconButton,
  List,
  ListItem,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  Popover,
  Stack,
  Toolbar,
  Typography,
} from "@mui/material";
import { useEffect, useState } from "react";
import { Outlet, useNavigate } from "react-router-dom";
import { StorageService } from "../services/storage.service";
import AccountCircleRoundedIcon from "@mui/icons-material/AccountCircleRounded";
import EmailIcon from "@mui/icons-material/Email";
import LocalPhoneIcon from "@mui/icons-material/LocalPhone";
import PsychologyIcon from "@mui/icons-material/Psychology";
import { UserInfo } from "../models/user-info";
import ManIcon from "@mui/icons-material/Man";
import WomanIcon from "@mui/icons-material/Woman";
import Man4Icon from "@mui/icons-material/Man4";
import KeyboardArrowDownIcon from "@mui/icons-material/KeyboardArrowDown";

export default function Landing() {
  const navigate = useNavigate();
  const currentUser = StorageService.getStoredUser();
  function logout() {
    StorageService.removeUser();
    navigate("/auth/login");
  }

  const [anchorEl, setAnchorEl] = useState<HTMLButtonElement | null>(null);

  const handleClick = (event: React.MouseEvent<HTMLButtonElement>) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  const open = Boolean(anchorEl);
  const id = open ? "profile-popover" : undefined;

  useEffect(() => {
    if (!currentUser) {
      logout();
    }
  }, [currentUser]);

  return (
    <Box sx={{ flexGrow: 1 }}>
      <AppBar position="fixed">
        <Container>
          <Toolbar className="mx-0 px-0">
            <Typography variant="h4" component="span" sx={{ flexGrow: 1 }}>
              BMI & Diet
            </Typography>

            <Button
              color="primary"
              size="small"
              variant="outlined"
              onClick={handleClick}
            >
              <Stack
                direction={"row"}
                alignItems={"center"}
                justifyContent={"start"}
                spacing={3}
                sx={{
                  color: "#fff",
                }}
              >
                <Stack
                  direction={"column"}
                  justifyContent={"start"}
                  sx={{
                    alignItems: "center !important",
                    justifyContent: "flex-start !important",
                  }}
                >
                  <Typography
                    variant="body2"
                    sx={{ textTransform: "capitalize" }}
                  >
                    Hello,{" "}
                  </Typography>
                  <Typography
                    variant="body1"
                    sx={{ textTransform: "capitalize" }}
                  >
                    {currentUser?.name ?? "--"}
                  </Typography>
                </Stack>

                <Stack direction={"row"} spacing={1}>
                  <Avatar
                    alt="User"
                    src="https://cdn4.iconfinder.com/data/icons/iconsimple-health/512/pulse_heart-512.png"
                    sx={{ width: 45, height: 45 }}
                  />
                  <IconButton size="small" sx={{ padding: 0 }}>
                    <KeyboardArrowDownIcon sx={{ color: "#fff" }} />
                  </IconButton>
                </Stack>
              </Stack>
            </Button>
          </Toolbar>
        </Container>
      </AppBar>
      <Container className="mt-5 pt-4">
        <Outlet />
      </Container>
      <div className="my-5 py-5"></div>

      <ProfilePopover
        id={id}
        isOpen={open}
        anchorEl={anchorEl}
        handleClose={handleClose}
        currentUser={currentUser ?? ({} as UserInfo)}
        logout={logout}
      />
    </Box>
  );
}

function ProfilePopover({
  id,
  isOpen,
  anchorEl,
  handleClose,
  currentUser,
  logout,
}: any) {
  const { name, email, phoneNumber, age, gender } = currentUser;

  function getGenderIcon() {
    switch (gender) {
      case "male":
        return <ManIcon />;
      case "female":
        return <WomanIcon />;
      default:
        return <Man4Icon />;
    }
  }

  return (
    <Popover
      id={id}
      open={isOpen}
      anchorEl={anchorEl}
      onClose={handleClose}
      anchorOrigin={{
        vertical: "bottom",
        horizontal: "center",
      }}
      transformOrigin={{
        vertical: "top",
        horizontal: "center",
      }}
    >
      <List
        sx={{
          width: "100%",
          bgcolor: "background.paper",
        }}
      >
        <ListItem>
          <ListItemIcon>
            <AccountCircleRoundedIcon />
          </ListItemIcon>
          <ListItemText primary="Name" secondary={name} />
        </ListItem>
        <ListItem>
          <ListItemIcon>
            <EmailIcon />
          </ListItemIcon>
          <ListItemText primary="Email" secondary={email} />
        </ListItem>
        <ListItem>
          <ListItemIcon>
            <LocalPhoneIcon />
          </ListItemIcon>
          <ListItemText primary="Phone number" secondary={phoneNumber} />
        </ListItem>
        <ListItem>
          <ListItemIcon>{getGenderIcon()}</ListItemIcon>
          <ListItemText primary="Gender" secondary={gender?.toUpperCase()} />
        </ListItem>
        <ListItem>
          <ListItemIcon>
            <PsychologyIcon />
          </ListItemIcon>
          <ListItemText primary="Age" secondary={age} />
        </ListItem>
      </List>

      <Divider />
      <List>
        <ListItem disablePadding>
          <ListItemButton onClick={logout}>
            <ListItemIcon>
              <LogoutIcon />
            </ListItemIcon>
            <ListItemText primary="Logout" />
          </ListItemButton>
        </ListItem>
      </List>
    </Popover>
  );
}
