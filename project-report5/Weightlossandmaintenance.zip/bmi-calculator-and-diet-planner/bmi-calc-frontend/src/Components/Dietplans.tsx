import ArrowCircleLeftOutlinedIcon from "@mui/icons-material/ArrowCircleLeftOutlined";
import FitnessCenterIcon from "@mui/icons-material/FitnessCenter";
import SetMealIcon from "@mui/icons-material/SetMeal";
import {
  Button,
  Card,
  CardContent,
  Grid,
  Stack,
  Tab,
  Tabs,
  Typography,
} from "@mui/material";
import { useEffect, useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { BmiData } from "../models/bmi-data";
import { BmiHelperService } from "../services/bmi-helper.service";

export function DietPlan() {
  const [searchParams] = useSearchParams();
  const [tab, setTab] = useState(0);
  const navigate = useNavigate();
  const [dietAndWorkouts, setDietAndWorkouts] = useState<BmiData>();
  const bmiCategory = searchParams.get("bmiCategory");

  useEffect(() => {
    if (bmiCategory) {
      const dietsAndWorkouts =
        BmiHelperService.getDietPlanByBmiCategory(bmiCategory);
      if (dietsAndWorkouts) {
        setDietAndWorkouts(dietsAndWorkouts);
      }
    }
  }, [bmiCategory]);

  const tabChange = (event: React.SyntheticEvent, newValue: number) => {
    setTab(newValue);
  };

  const getTabPanel = () => {
    if (tab === 0) {
      return (
        <Stack spacing={3}>
          <Card variant="outlined">
            <CardContent>
              <Typography variant="h4">
                Comprehensive diet plan for{" "}
                <span
                  className={BmiHelperService.getBmiCategoryColorClass(
                    bmiCategory ?? ""
                  )}
                >
                  {bmiCategory?.toLowerCase()}
                </span>{" "}
                individuals
              </Typography>
            </CardContent>
          </Card>

          <Card elevation={2}>
            <CardContent>
              <Grid container spacing={2}>
                {dietAndWorkouts?.diet.map((section, index) => (
                  <Grid item xs={12} key={index}>
                    <span
                      dangerouslySetInnerHTML={{ __html: section.header }}
                    ></span>
                    <Typography variant="body1">
                      <div
                        dangerouslySetInnerHTML={{ __html: section.content }}
                      ></div>
                    </Typography>
                  </Grid>
                ))}
              </Grid>
            </CardContent>
          </Card>
        </Stack>
      );
    } else if (tab === 1) {
      return (
        <Stack spacing={3}>
          <Card variant="outlined">
            <CardContent>
              <Typography variant="h4">
                Comprehensive workout plan for{" "}
                <span
                  className={BmiHelperService.getBmiCategoryColorClass(
                    bmiCategory ?? ""
                  )}
                >
                  {bmiCategory?.toLowerCase()}
                </span>{" "}
                individuals
              </Typography>
            </CardContent>
          </Card>

          <Card elevation={2}>
            <CardContent>
              <Grid container spacing={2}>
                {dietAndWorkouts?.workout.map((section, index) => (
                  <Grid item xs={12} key={index}>
                    <span
                      dangerouslySetInnerHTML={{ __html: section.header }}
                    ></span>
                    <Typography variant="body1">
                      <div
                        dangerouslySetInnerHTML={{ __html: section.content }}
                      ></div>
                    </Typography>
                  </Grid>
                ))}
              </Grid>
            </CardContent>
          </Card>
        </Stack>
      );
    }
    return <></>;
  };

  return (
    <>
      {bmiCategory && dietAndWorkouts && (
        <Stack direction={"column"} spacing={3}>
          <Stack direction={"row"} justifyContent={"space-between"}>
            <Button
              startIcon={<ArrowCircleLeftOutlinedIcon />}
              size="large"
              onClick={() => navigate("/bmi", { replace: true })}
            >
              Back
            </Button>

            <Tabs
              value={tab}
              onChange={tabChange}
              textColor="secondary"
              indicatorColor="secondary"
            >
              <Tab
                label="Suggested Diet"
                icon={<SetMealIcon />}
                iconPosition="start"
              />
              <Tab
                label="Workout plan"
                icon={<FitnessCenterIcon />}
                iconPosition="start"
              />
            </Tabs>
          </Stack>

          {getTabPanel()}
        </Stack>
      )}
    </>
  );
}
