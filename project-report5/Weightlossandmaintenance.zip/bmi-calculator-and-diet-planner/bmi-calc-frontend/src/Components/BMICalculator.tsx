import {
  Button,
  Card,
  CardContent,
  InputAdornment,
  Paper,
  Stack,
  TextField,
  Typography,
} from "@mui/material";
import React from "react";
import { BMICategory } from "../models/bmi-category.enum";

export default function BMICalculator({
  setBmiCategory,
  getBmiCategoryColorClass,
}: any) {
  const [vitals, setVitals] = React.useState({
    height: "",
    weight: "",
  });

  const [bmi, setBmi] = React.useState({
    bmi: "",
    category: "",
  });

  function onChange(event: any) {
    if (!Number.isNaN(event.target.value)) {
      setVitals((currentValue: any) => ({
        ...currentValue,
        [event.target.name]: event.target.value,
      }));
    }
  }

  function getBmiCategory(bmi: number) {
    let category = "";
    if (bmi < 18.5) {
      category = BMICategory.Underweight;
    } else if (bmi >= 18.5 && bmi < 25) {
      category = BMICategory.NormalWeight;
    } else if (bmi >= 25 && bmi < 30) {
      category = BMICategory.Overweight;
    } else {
      category = BMICategory.Obesity;
    }
    setBmiCategory(category);
    return category;
  }

  function onCalculate() {
    const height = vitals.height;
    const weight = vitals.weight;

    if (!height?.trim() || !weight?.trim()) {
      alert("Height and weight are required !!");
      return;
    }

    if (Number.isNaN(height) || Number.isNaN(weight)) {
      alert("Height and weight are required and should to be valid numbers");
      return;
    }

    if (parseFloat(height) <= 0 || parseFloat(weight) <= 0) {
      alert("Height or weight should be greater than zero");
      return;
    }

    const heightInMeters = parseFloat(height) / 100;
    const weightInKg = parseFloat(weight);
    const bmi = weightInKg / heightInMeters ** 2;

    setBmi({
      bmi: bmi.toFixed(1),
      category: getBmiCategory(bmi),
    });
  }

  return (
    <div className="w-100 d-flex align-items-center justify-content-evenly flex-wrap">
      <form
        onSubmit={(e: any) => {
          e?.preventDefault();
          onCalculate();
        }}
      >
        <Card sx={{ minWidth: 400 }} className="mb-4 mb-md-0">
          <CardContent>
            <Stack direction={"column"} spacing={3}>
              <Typography variant="h5">BMI Calculator</Typography>

              <TextField
                label="Height"
                placeholder="Your height please"
                InputProps={{
                  endAdornment: (
                    <InputAdornment position="start">cm</InputAdornment>
                  ),
                }}
                type="number"
                name="height"
                value={vitals.height}
                onChange={onChange}
              />

              <TextField
                label="Weight"
                placeholder="Your weight please"
                InputProps={{
                  endAdornment: (
                    <InputAdornment position="start">kg</InputAdornment>
                  ),
                }}
                type="number"
                name="weight"
                value={vitals.weight}
                onChange={onChange}
              />
              <Stack direction={"row"} justifyContent={"space-between"}>
                <Button
                  variant="text"
                  color="primary"
                  onClick={() => {
                    setBmi({ bmi: "", category: "" });
                    setVitals({ height: "", weight: "" });
                    setBmiCategory("");
                  }}
                  type="button"
                >
                  Clear
                </Button>

                <Button
                  variant="contained"
                  color="success"
                  onClick={onCalculate}
                  type="submit"
                >
                  Calculate
                </Button>
              </Stack>
            </Stack>
          </CardContent>
        </Card>
      </form>

      <Paper elevation={0}>
        {bmi.bmi && bmi.category ? (
          <Stack spacing={3}>
            <div>
              <Typography>You BMI is:</Typography>
              <Typography variant="h4">{bmi.bmi}</Typography>
            </div>

            <div>
              <Typography>And falls under:</Typography>
              <Typography
                variant="h4"
                className={getBmiCategoryColorClass(bmi.category)}
              >
                {bmi.category}
              </Typography>
            </div>
          </Stack>
        ) : (
          <Typography variant="h5">
            You BMI results will appear here...
          </Typography>
        )}
      </Paper>
    </div>
  );
}
