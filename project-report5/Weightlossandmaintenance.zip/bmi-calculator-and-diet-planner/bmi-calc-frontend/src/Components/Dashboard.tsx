import ChevronRightIcon from "@mui/icons-material/ChevronRight";
import {
  Card,
  CardContent,
  Divider,
  IconButton,
  Stack,
  Typography,
} from "@mui/material";
import React from "react";
import doctorImage from "../assets/doctor.jpg";
import { BmiHelperService } from "../services/bmi-helper.service";
import BMICalculator from "./BMICalculator";
import { useNavigate } from "react-router-dom";
export default function Dashboard() {
  const [bmiCategory, setBmiCategory] = React.useState("");
  const navigate = useNavigate();

  return (
    <Stack direction={"column"} spacing={10}>
      <Stack
        direction={"row"}
        justifyContent={"space-evenly"}
        alignItems={"center"}
        spacing={10}
        className="mt-5"
        flexWrap={"wrap"}
      >
        <img
          src={doctorImage}
          className="img-fluid"
          style={{ height: "400px" }}
          alt="doctor"
        />

        <Stack width={"50%"} spacing={3}>
          <Typography variant="h4" component={"h4"}>
            Body Mass Index (BMI)
          </Typography>
          <Typography
            component={"p"}
            variant="body1"
            style={{ textAlign: "justify" }}
          >
            The Body Mass Index (BMI) is a measure of body fat based on height
            and weight. Keep in mind that while BMI is a useful screening tool,
            it does not directly assess body fat and may not be accurate for
            everyone (such as athletes with high muscle mass). It's always a
            good idea to consult with a healthcare professional for a
            comprehensive assessment. Here are the general BMI categories:
            <ul style={{ listStyleType: "none" }} className="mx-0 px-0 mt-2">
              <li>
                <b>Underweight</b>: BMI less than 18.5
              </li>
              <li>
                <b>Normal weight</b>: BMI 18.5 to 24.9
              </li>
              <li>
                <b>Overweight</b>: BMI 25 to 29.9
              </li>
              <li>
                <b>Obesity</b>: BMI 30 or greater
              </li>
            </ul>
          </Typography>
        </Stack>
      </Stack>

      <Stack direction={"column"} spacing={5}>
        <Divider>
          <Typography variant="h4">Calculate your BMI</Typography>
        </Divider>
        <BMICalculator
          setBmiCategory={setBmiCategory}
          getBmiCategoryColorClass={BmiHelperService.getBmiCategoryColorClass}
        />
      </Stack>

      {bmiCategory && (
        <div
          onClick={() =>
            navigate(`/bmi/diet-and-workout?bmiCategory=${bmiCategory}`)
          }
        >
          <Card
            className={`${BmiHelperService.getBmiCategoryColorClass(
              bmiCategory
            )}-bg`}
            sx={{
              borderRadius: "1rem",
              cursor: "pointer",
            }}
          >
            <CardContent className="pb-3">
              <Stack direction={"row"} justifyContent={"space-between"}>
                <Typography variant="h4" sx={{ fontWeight: "lighter" }}>
                  Get detailed diet and workout plan for {bmiCategory}
                </Typography>

                <IconButton>
                  <ChevronRightIcon sx={{ color: "#fff" }} />
                </IconButton>
              </Stack>
            </CardContent>
          </Card>
        </div>
      )}
    </Stack>
  );
}
