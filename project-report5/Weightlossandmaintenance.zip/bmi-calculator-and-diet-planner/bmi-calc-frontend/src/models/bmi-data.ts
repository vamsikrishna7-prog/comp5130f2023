import { BMICategory } from "./bmi-category.enum";

export interface BmiData {
  bmiCategory: string;
  header: string;
  workout: DietSection[];
  diet: DietSection[];
}

export interface DietSection {
  header: string;
  content: string;
}
