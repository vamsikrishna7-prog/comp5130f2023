export enum BMICategory {
  Underweight = "Underweight",
  NormalWeight = "Normal weight",
  Overweight = "Overweight",
  Obesity = "Obesity",
}
