export interface UserInfo {
  id?: any;
  name?: string;
  email: string;
  password: string;
  age: number;
  phoneNumber: string;
  gender: string;
}
