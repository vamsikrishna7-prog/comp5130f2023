import { UserInfo } from "../models/user-info";
import axios from "axios";
export class AuthService {
  private static readonly API = "/user";

  public static registerUser(userInfo: UserInfo): Promise<any> {
    return axios.post(`${AuthService.API}/create-account`, { ...userInfo });
  }

  public static loginUser(
    userInfo: Omit<UserInfo, "age" | "phoneNumber" | "gender">
  ): Promise<any> {
    return axios.post(`${AuthService.API}/login`, { ...userInfo });
  }
}
