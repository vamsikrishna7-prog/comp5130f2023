import dietPlan from "../assets/diet-plan.json";
import { BmiData } from "../models/bmi-data";

export class BmiHelperService {
  public static getBmiCategoryColorClass(bmiCategory: string) {
    switch (bmiCategory) {
      case "Underweight":
        return "bmi-underweight";
      case "Normal weight":
        return "bmi-normal-weight";
      case "Overweight":
        return "bmi-overweight";
      case "Obesity":
        return "bmi-obesity";
      default:
        return "";
    }
  }

  public static getDietPlanByBmiCategory(bmiCategory: string): BmiData {
    const dp = (dietPlan as any)[bmiCategory];
    return dp ?? {};
  }
}
