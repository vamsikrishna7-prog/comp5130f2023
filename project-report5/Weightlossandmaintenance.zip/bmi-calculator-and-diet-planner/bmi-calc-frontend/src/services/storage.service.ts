import { UserInfo } from "../models/user-info";

export class StorageService {
  private static readonly userKey = "user";
  public static getStoredUser(): UserInfo | null {
    const user = localStorage.getItem(StorageService.userKey);
    return user ? JSON.parse(user) : null;
  }

  public static rememberUser(userInfo: UserInfo): void {
    localStorage.setItem(StorageService.userKey, JSON.stringify(userInfo));
  }

  public static removeUser(): void {
    localStorage.removeItem(StorageService.userKey);
  }
}
