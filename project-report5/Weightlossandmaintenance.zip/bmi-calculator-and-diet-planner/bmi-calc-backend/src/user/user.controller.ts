import { Body, Controller, Post } from '@nestjs/common';
import { CreateUserDto } from './dto/create-user.dto';
import { UserService } from './user.service';

@Controller('user')
export class UserController {
  constructor(private readonly userService: UserService) {}

  @Post('create-account')
  async createUser(@Body() createUserDto: CreateUserDto) {
    try {
      const user = await this.userService.create(createUserDto);
      return { status: 200, user, message: 'User created successfully' };
    } catch (error) {
      console.log(error);
      return { status: error?.getStatus() ?? 400, message: error.message };
    }
  }

  @Post('login')
  async loginUser(
    @Body('email') email: string,
    @Body('password') password: string,
  ) {
    try {
      const loginResult = await this.userService.login(email, password);
      return {
        status: loginResult.status ?? 200,
        user: loginResult.user,
        message: loginResult.message,
      };
    } catch (error) {
      console.log(error);
      return { status: error?.getStatus() ?? 400, message: error.message };
    }
  }
}
