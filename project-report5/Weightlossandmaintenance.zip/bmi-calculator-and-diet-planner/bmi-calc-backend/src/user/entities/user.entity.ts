import {
  Column,
  PrimaryKey,
  Table,
  Model,
  AutoIncrement,
} from 'sequelize-typescript';

@Table
export class User extends Model {
  @PrimaryKey
  @AutoIncrement
  @Column
  id: number;
  @Column
  name: string;
  @Column
  email: string;
  @Column
  password: string;
  @Column
  age: number;
  @Column
  phoneNumber: string;
  @Column
  gender: string;
}
