export class CreateUserDto {
  name: string;
  email: string;
  password: string;
  phoneNumber: string;
  age: number;
  gender: string;
}
