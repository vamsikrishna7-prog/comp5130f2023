import { Module } from '@nestjs/common';
import { databaseProviders } from 'src/providers/db.provider';

@Module({
  providers: [...databaseProviders],
})
export class DatabaseModule {}
