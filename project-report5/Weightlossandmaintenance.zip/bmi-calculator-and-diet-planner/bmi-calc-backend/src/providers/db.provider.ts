import { Sequelize } from 'sequelize-typescript';
import { SEQUELIZE_PROVIDER } from 'src/constants';
import { User } from 'src/user/entities/user.entity';

function getEnvValue<T>(key: string) {
  return process.env[key] as T;
}

export const databaseProviders = [
  {
    provide: SEQUELIZE_PROVIDER,
    useFactory: async () => {
      const sequelize = new Sequelize({
        dialect: 'mysql',
        host: getEnvValue<string>('DATABASE_SERVER'),
        port: getEnvValue<number>('DATABASE_PORT'),
        username: getEnvValue<string>('DATABASE_USER'),
        password: getEnvValue<string>('DATABASE_PASSWORD'),
        database: getEnvValue<string>('DATABASE_NAME'),
      });
      sequelize.addModels([User]);
      await sequelize.sync({ force: false });
      return sequelize;
    },
  },
];
